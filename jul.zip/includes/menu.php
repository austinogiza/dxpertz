		<div class="menu">
			<li class="item">
				
				<a href="" class="btn"> <i class="fas fa-user-alt"></i> &nbsp Profile</a>
<div class="smenu"><a href="">Course</a>
	<a href="profile.php">Profile</a></div>
			</li>
<li class="item">
				
				<a href="" class="btn"><i class="fas fa-envelope"></i>&nbspMessages</a>
				<div class="smenu"><a href="">New</a>
	<a href="">Sent</a></div>
			</li>

<li class="item">
				
				<a href="" class="btn"><i class="fas fa-cog"></i>&nbspSetting</a>
				<div class="smenu"><a href="">Password</a>
	<a href="">Setting</a></div>
			</li>


<li class="item">
				
				<a href="processes/logoutprocess.php" class="btn"> <i class="fas fa-sign-out-alt"></i> &nbspLogout</a>
			</li>


		</div>


	