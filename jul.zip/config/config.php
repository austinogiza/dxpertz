<?php  

$connection=mysqli_connect("localhost" , "root", "", "dx");

if (mysqli_connect_errno($connection)) 

{
	die ("Database connection Error");
}


?>