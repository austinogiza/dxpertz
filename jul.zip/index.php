<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>D-XPERTS - The Digital Company</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="css/main.css" />
    <script src="main.js"></script>

    <link rel="stylesheet" href="css/tab.css">

    <link rel="stylesheet" href="css/nav.css">
    
    <link rel="stylesheet" href="css/drop.css">

    <link rel="stylesheet" href="css/slider.css">


<link rel="stylesheet" href="fontawesome-free-5.6.3-web/css/all.css" />
		<link rel="stylesheet" href="fontawesome-free-5.6.3-web/css/fontawesome.css" />
		<link rel="stylesheet" href="fontawesome-free-5.6.3-web/webfonts" />
	<script src="js/jquery-3.3.1.min.js"></script>

	<script src="js/jquery.counterup.min.js"></script>
	<script src="js/scrollreveal.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js"></script>
</head>
<body>

	<div class="logo">
		
<div class="log">
	

</div>
<div class="social">
	
	<ul>
	<li><a href="#" target="_blank"><i class="fab fa-facebook-f" aria-hidden="true"></i></a></li>
	<li><a href="#" target="_blank"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
	<li><a href="#" target="_blank"><i class="fab fa-instagram" aria-hidden="true"></i></a></li>
<li><a href="#" target="_blank"><i class="fab fa-whatsapp" aria-hidden="true"></i></a></li>



</ul>
</div>
	</div>
   <div class="header"> 

   	<nav>

   		<ul>
   				<li><a href="index.php">Home</a></li>

   			<li><a href="about.php">Who Are We &nbsp<i class="fas fa-caret-down"></i></a>
   				<ul>
   					<li><a href="">Overview</a></li>
   					<li><a href="">Career</a></li>
   					<li><a href="">Partners</a></li>
   					<li><a href="">Corporate Profile</a></li>
   				</ul>
   			</li>

   			<li><a href="programmes.php">What We Do &nbsp<i class="fas fa-caret-down"></i></a>
   				<ul>   					
   					<li><a href="">Services</a></li>
   					<li><a href="">Product 2</a></li>
   					<li><a href="">Product3</a></li>
   					<li><a href="">Product 4</a></li>
   				</ul>
   			</li>
   			<li><a href="contact.php">Contact Us</a></li>

<span class="sideheader"><a href="login.php"><i class="far fa-user-circle"></a></i>&nbsp<i class="fas fa-bars bar" onclick="openSideMenu()"></i></span> 
   		</ul>
   	</nav>
 </div>

  </div>

<div id="side-menu" class="side-nav">
		<a href="#" class="btn-close" onclick="closeSideMenu()"><i class="fas fa-times"></i></a>
		<ul>
<li><a href="">Home</a></li>

   			<li><a href="about.php">Who Are We</a>
   			</li>

   			<li><a href="programmes.php">What We Do </a>

</li>
   			<li><a href="contact.php">Contact Us</a></li>

	</div>	



<!--slider area -->
<div class="slid">

<div class="wrap">
  
  <div id="arrow-left" class="arrow"></div>

<div id="slider">
  <div class="slide slide1">
  
  <div class="slide-content">
    
    <span>
      Image One
    </span>
  </div>
</div>  

<div class="slide slide2">
  
  <div class="slide-content">
    
    <span>
      Image Two
    </span>
  </div>
</div>  

<div class="slide slide3">
  
  <div class="slide-content">
    
    <span>
      Image Three
    </span>
  </div>
</div>  

  <div id="arrow-right" class="arrow"></div>
</div>
</div>

</div>

<div class="events">
	
	<div class="we">
		Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos pariatur repudiandae dolorem. Iusto commodi at, doloribus deleniti quo optio unde suscipit veritatis. Architecto consectetur ut totam soluta, repudiandae aperiam reiciendis.
	</div>

	<div class="we">
		<img src="images/blogging.jpg" alt="">
	</div>

	<div class="we">
		<img src="images/web.jpg" alt="">
		
	</div>

	<div class="we">
		Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto, architecto blanditiis. Quaerat accusamus aperiam nesciunt molestias harum vero minima veniam, suscipit, possimus reprehenderit reiciendis repellat quasi magni quisquam minus distinctio.
	</div>
</div>
<div class="courses">
	<h3>Available Training Programmes.</h3>

<div class="tabContainer">
<div class="buttonContainer">
	
	<button onclick="showPanel(0, '#f44336')">ORACLE WDP</button>
	<button onclick="showPanel(1, '#3498db')">Tab 2</button>
	<button onclick="showPanel(2, '#2ecc71')">Tab 3</button>
	<button onclick="showPanel(3, '#c0392b')">Tab 4</button>
	<button onclick="showPanel(4, '#9b59b6')">MICROSOFT</button>
	<button onclick="showPanel(5, '#f1c40f')">MICROSOFT</button>
</div>



<div class="tabPanel">
ORACLE 12C <br/>
ORACLE JAVA <br/>
PHP / MYSQL <br/>
ORACLE PRIMAVERA <br/>
</div>


<div class="tabPanel">
	
CCNA <br/>
CCNP <br/>
</div>

<div class="tabPanel">
	WEB-DESIGN <br/>
CREATIVE PUBLICATION <br/>
PHP <br/>
</div>
<div class="tabPanel">
	
COMPTIA A+ <br/>
SECURITY + <br/>
COMPTIA N+ <br/>
</div>

<div class="tabPanel">
	
ARCHICARD <br/>
PEACHTREE <br/>
ITIL<br/>
CISA<br/>
</div>

<div class="tabPanel">
MS-OFFICE <br>
PROJECT MANAGEMENT <br>
MCSE <br>
MS SQL-DATABASE <br>
</div>
</div>

</div>

<div class="register">
	
	<h3>
I.T Training at D-Xpertz <br>
D-Xpertz is built to keep you connected and informed with the latest developement in the I.T world</h3>

<a href="signup.php">Sign Up Now &nbsp<i class="fas fa-chevron-right"></i></a>
</div>

<div class="at">
	
<h1> life At D-Xpertz &nbsp<i class="fas fa-play-circle"></i></h1>
</div>

<div class="work"><h1>The Competitive Edge</h1>
	<p>Hard to beat, and impossible to miss.</p>

	<h3>Let's Work Together</h3></div>

<div class="middle">
	
	<div class="counting-sec">
		
		<div class="inner-width">
			<div class="col">
			<i class="far fa-smile-wink"></i>
			<div class="num">
				10000
			</div>
			speaker
		</div>
		<div class="col">
			<i class="fas fa-briefcase"></i>
			<div class="num">
				500
			</div>
			Courses
		</div>
		<div class="col">
			<i class="far fa-money-bill-alt"></i>
			<div class="num">
				100
			</div>
			Templates
		</div>
		<div class="col">
			<i class="far fa-object-group"></i>
			<div class="num">
				1000
			</div>
			speaker
		</div>

		</div>
	</div>
</div>	
<div class="footer">
	<div class="contact"><h3>Contact Us</h3>

<p>&nbsp<i class="fas fa-map-marker-alt"></i>&nbsp&nbsp 27 Airport Road Ede Plaza, Benin City, <br> &nbsp&nbsp&nbsp&nbsp Edo State, Nigeria<br></p>
<p>&nbsp<i class="fas fa-phone"></i>&nbsp&nbspPhone : +234 805 596 4598</p>
<p>&nbsp <i class="fas fa-envelope"></i>&nbsp&nbspEmail: info@.com</p>	</div>
<div class="quick"><h3>Quick Link</h3>
<ul>
	<li><a href="">Account Profile</a></li>
	<li><a href="">Careers</a></li>
	<li><a href="">About Us</a></li>
	<li><a href="">Blog</a></li>
	<li><a href="">Contact Us</a></li>
</ul>

</div>

<div class="dx"><h3>About</h3></div>
<div class="dxlogo">
	

	
</div>
</div>

<div class="copyright">
	<div class="copy"><p>©&nbsp <?php echo date("Y"); ?> DXpertz Technology, All rights reserved.</p></div>

</div>

<span class="arrowup"><i class="fas fa-arrow-up"></i></span>
</body>
</html>
<script>
	
let sliderImages = document.querySelectorAll('.slide'),
 arrowRight = document.querySelector('#arrow-right'),
 arrowLeft = document.querySelector('#arrow-left'),
 current = 0;

 //clear all images
 function reset(){
for (let i = 0; i < sliderImages.length; i++) {
  sliderImages[i].style.display ='none';
}
 }

 function startSlide() {
  reset();
  sliderImages[0].style.display = 'block';
 }

 function slideLeft(){
 reset();
 sliderImages[current -1].style.display ='block';
 current--; 
 }

 function slideRight(){
 reset();
 sliderImages[current + 1].style.display = 'block';
 current++; 
 }

// left arrow click

arrowLeft.addEventListener('click', function(){
   if(current === 0){
    current = sliderImages.length;
  }
  slideLeft();
});


// Right arrow click

arrowRight.addEventListener('click', function(){
   if(current === sliderImages.length -1){
    current = - 1;
  }

  slideRight();
});

 startSlide();


function openSideMenu() {

	document.getElementById('side-menu').style.width="250px";
	document.getElementById('main').style.marginleft="250px";
}	
 function closeSideMenu ()
 {

 	document.getElementById('side-menu').style.width="0px";
 	document.getElementById('main').style.marginleft="0px";
 	

 }
 
var tabButtons=document.querySelectorAll(".tabContainer .buttonContainer button");
var tabPanels=document.querySelectorAll(".tabContainer .tabPanel");

function showPanel(panelIndex, colorCode){
	tabButtons.forEach(function(node) {
		node.style.backgroundColor="";
		node.style.color="";
		
	});

	tabButtons[panelIndex].style.backgroundColor=colorCode;
	tabButtons[panelIndex].style.color="white";
	tabPanels.forEach(function(node){
			node.style.display="none";
	});
	tabPanels[panelIndex].style.display="block";
	tabPanels[panelIndex].style.backgroundColor=colorCode;
}

	showPanel(0, '#f44336');


	$(document).ready(()=>{


$('.num').counterUp({delay:10,time:1000});


 $(window).scroll(()=>{

	if($(this).scrollTop() >40)
	{
		$('.arrowup').fadeIn();
}

else{
$('.arrowup').fadeOut(); 
}

});

$('.arrowup').click(()=>{
	$('html ,body').animate({scrollTop: 0}, 800);
});


});

</script>