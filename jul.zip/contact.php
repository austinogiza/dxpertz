<?php
session_start();
require_once("config/config.php"); 
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>IT XPERTS</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="css/main.css" />
    <script src="main.js"></script>

    <link rel="stylesheet" href="css/contact.css">

    <link rel="stylesheet" href="css/nav.css">

    
    <link rel="stylesheet" href="css/drop.css">

<link rel="stylesheet" href="fontawesome-free-5.6.3-web/css/all.css" />
		<link rel="stylesheet" href="fontawesome-free-5.6.3-web/css/fontawesome.css" />
		<link rel="stylesheet" href="fontawesome-free-5.6.3-web/webfonts" />
	<script src="js/jquery-3.3.1.min.js"></script>

	<script src="js/jquery.counterup.min.js"></script>
	<script src="js/scrollreveal.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js"></script>
</head>
<body>

	<div class="logo">
		
<div class="log">
	

</div>
<div class="social">
	
	<ul>
	<li><a href="#" target="_blank"><i class="fab fa-facebook-f" aria-hidden="true"></i></a></li>
	<li><a href="#" target="_blank"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>
	<li><a href="#" target="_blank"><i class="fab fa-instagram" aria-hidden="true"></i></a></li>
<li><a href="#" target="_blank"><i class="fab fa-whatsapp" aria-hidden="true"></i></a></li>



</ul>
</div>
	</div>
     <div class="header"> 

   	<nav>

   		<ul>
   				<li><a href="index.php">Home</a></li>

   			<li><a href="about.php">Who Are We &nbsp<i class="fas fa-caret-down"></i></a>
   				<ul>
   					<li><a href="">Overview</a></li>
   					<li><a href="">Career</a></li>
   					<li><a href="">Partners</a></li>
   					<li><a href="">Corporate Profile</a></li>
   				</ul>
   			</li>

   			<li><a href="programmes.php">What We Do &nbsp<i class="fas fa-caret-down"></i></a>
   				<ul>   					
   					<li><a href="">Services</a></li>
   					<li><a href="">Product 2</a></li>
   					<li><a href="">Product3</a></li>
   					<li><a href="">Product 4</a></li>
   				</ul>
   			</li>
   			<li><a href="contact.php">Contact Us</a></li>

<span class="sideheader"><a href="login.php"><i class="far fa-user-circle"></a></i>&nbsp<i class="fas fa-bars bar" onclick="openSideMenu()"></i></span> 
   		</ul>
   	</nav>
 </div>

  </div>

<div id="side-menu" class="side-nav">
		<a href="#" class="btn-close" onclick="closeSideMenu()"><i class="fas fa-times"></i></a>
		<ul>
<li><a href="">Home</a></li>

   			<li><a href="about.php">Who Are We</a>
   			</li>

   			<li><a href="programmes.php">What We Do </a>

</li>
   			<li><a href="contact.php">Contact Us</a></li>

	</div>	

<div class="contactpage">

<div class="alert">	</div>
<div id="nav">
<?php 

	if (isset($_SESSION['error'])) {
?>

<div class="errorclass"><p> Please Fill In All Fields</p>
</div>
<?php
}


?>

<?php 

	if (isset($_SESSION['success']) && $_SESSION['success']=='mailsent'){
?>

<div class="success"><p>Thank You, Your Mail has Been Sent!</p>
</div>
<?php

unset($_SESSION['error']);
unset($_SESSION['name']);
unset($_SESSION['number']);
unset($_SESSION['budget']);
unset($_SESSION['email']);
unset($_SESSION['message']);

	}
?>

</div>


	
<div class="items">
	
	<div class="contactform"><h1>Contact Information.</h1>
	<p>
For inquiries and more information about our programmes and updates, please kindly fill the form below with your contact details.</p> 

<form action="processes/contactprocess.php" method="post">
	
	<div><label>Name:<input type="text" name="name" class="cont <?php
    if( !isset($_SESSION['name']) && isset($_SESSION['error']) )
echo 'error';

			?>" value="<?php 

			if(isset($_SESSION['name']))
			{
echo $_SESSION['name'];
			}

			?>"
			 value="<?php 

			if(isset($_SESSION['name']))
			{
echo $_SESSION['name'];
			}
			?>"></label></div>
	<div><label>Email:<input type="text" name="email" class="cont <?php
    if( !isset($_SESSION['email']) && isset($_SESSION['error']) )
echo 'error';

			?>" value="<?php 

			if(isset($_SESSION['email']))
			{
echo $_SESSION['email'];
			}

			?>"
			 value="<?php 

			if(isset($_SESSION['email']))
			{
echo $_SESSION['email'];
			}
			?>"></label></div>
	<div><label>Phone:<input type="text" name="phone" class="cont <?php
    if( !isset($_SESSION['phone']) && isset($_SESSION['error']) )
echo 'error';

			?>" value="<?php 

			if(isset($_SESSION['phone']))
			{
echo $_SESSION['phone'];
			}

			?>"
			 value="<?php 

			if(isset($_SESSION['phone']))
			{
echo $_SESSION['phone'];
			}
			?>"></label></div>
	<div><label>Message:<textarea class="<?php
    if( !isset($_SESSION['message']) && isset($_SESSION['error']) )
echo 'error';

			?>" value="<?php 

			if(isset($_SESSION['message']))
			{
echo $_SESSION['message'];
			}

			?>"
			 value="<?php 

			if(isset($_SESSION['message']))
			{
echo $_SESSION['message'];
			}
			?>" name="message"></textarea></label></div>
	<input type="submit" class="contactbtn" value="Send">
</form>

</div>

	<div class="location">
		
		Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eum iure eos, perferendis iste totam cupiditate iusto, est laudantium repellendus expedita! Repudiandae ducimus voluptatum explicabo necessitatibus a similique amet earum quae.
	</div>
</div>
</div>
<div class="footer">
	<div class="contact"><h3>Contact Us</h3>

<p>&nbsp<i class="fas fa-map-marker-alt"></i>&nbsp&nbsp 27 Airport Road Ede Plaza, Benin City, <br> &nbsp&nbsp&nbsp&nbsp Edo State, Nigeria<br></p>
<p>&nbsp<i class="fas fa-phone"></i>&nbsp&nbspPhone : +234 805 596 4598</p>
<p>&nbsp <i class="fas fa-envelope"></i>&nbsp&nbspEmail: info@.com</p>	</div>
<div class="quick"><h3>Quick Link</h3>
<ul>
	<li><a href="">Account Profile</a></li>
	<li><a href="">Careers</a></li>
	<li><a href="">About Us</a></li>
	<li><a href="">Blog</a></li>
	<li><a href="">Contact Us</a></li>
</ul>

</div>

<div class="dx"><h3>About</h3></div>
<div class="dxlogo">
	

	
</div>
</div>

<div class="copyright">
	<div class="copy"><p>©&nbsp<?php echo date("Y"); ?> DXpertz Technology, All rights reserved.</p></div>

</div>

<span class="arrowup"><i class="fas fa-arrow-up"></i></span>
</body>
</html>
<script>
	
function openSideMenu() {

	document.getElementById('side-menu').style.width="250px";
	document.getElementById('main').style.marginleft="250px";
}	
 function closeSideMenu ()
 {

 	document.getElementById('side-menu').style.width="0px";
 	document.getElementById('main').style.marginleft="0px";
 	

 }

	$(document).ready(()=>{

 $(window).scroll(()=>{

	if($(this).scrollTop() >40)
	{
		$('.arrowup').fadeIn();
}

else{
$('.arrowup').fadeOut(); 
}

});

$('.arrowup').click(()=>{
	$('html ,body').animate({scrollTop: 0}, 800);
});


});

</script>


<?php
unset($_SESSION['error']);
unset($_SESSION['name']);
unset($_SESSION['phone']);
unset($_SESSION['email']);
unset($_SESSION['message']);
unset($_SESSION['success']);
?>
